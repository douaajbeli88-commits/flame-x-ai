# FLAME-X — prototype d'IA de détection et de localisation d'incendie par drone

> *Anticiper • Détecter • Localiser • Protéger* — groupe powerpuff girls

Ce dépôt contient le **prototype du modèle d'intelligence artificielle** du projet FLAME-X (surveillance par drone des
incendies dans une raffinerie pétrolière). Il couvre les blocs **Traitement** et **Cartographie** de l'architecture du projet :

```
 Drone (caméra RGB, caméra thermique, GPS, capteur de gaz)
        │
        ▼
 ┌──────────────────────────── TRAITEMENT (ce dépôt) ───────────────────────────┐
 │ Caméra → modèle YOLOv8 (feu / fumée) ─┐                                        │
 │ Thermique → points chauds + tendance ─┼─► FUSION → score + niveau d'alerte     │
 │ Gaz (%LIE) ───────────────────────────┘        │                               │
 │                                                ▼                               │
 │      LOCALISATION : pixel + GPS + cap + angle caméra → position du foyer ±marge│
 └────────────────────────────────────────────────┬───────────────────────────────┘
                                                   ▼
        Alerte (image + JSON + GeoJSON) ──► CARTE (rouge / orange) ──► Centre de contrôle
                                                          └─► décision HUMAINE (jamais automatique)
```

**Le drone n'est pas un pompier autonome** : le système propose, l'humain valide.

## 1. Ce que fait chaque dossier

```
flame-x-ai/
├── README.md                 <- ce fichier
├── requirements.txt          <- liste des outils à installer
├── configs/flamex.yaml       <- TOUS les réglages (seuils, caméra, GPS...) sans toucher au code
├── scripts/                  <- les programmes que VOUS lancez
│   ├── check_setup.py        <- vérifie l'installation
│   ├── extract_frames.py     <- extrait des images d'une vidéo
│   ├── prepare_dataset.py    <- prépare la base d'images (train / val / test)
│   ├── train.py              <- ENTRAÎNE le modèle
│   ├── evaluate.py           <- MESURE la qualité (précision, rappel, mAP, vitesse, fausses alertes)
│   ├── run_detection.py      <- UTILISE le modèle : caméra + thermique + gaz → alerte localisée
│   └── make_map.py           <- carte HTML des alertes
├── flamex/                   <- les "briques" de code (appelées par les scripts)
│   ├── fusion.py             <- combine les indices et décide du niveau d'alerte
│   ├── thermal.py            <- points chauds + hausse inhabituelle de température
│   ├── geolocation.py        <- du pixel de l'image à la position GPS (+ marge d'erreur)
│   ├── telemetry.py          <- position/cap du drone (simulée ou MAVLink)
│   ├── sensors.py            <- gaz (simulé ; à remplacer par un capteur certifié)
│   └── alerts.py             <- journal, images, GeoJSON, envoi au centre de contrôle
├── tests/                    <- vérifications automatiques de la logique
├── notebooks/train_colab.ipynb <- entraînement sur Google Colab (GPU gratuit)
├── data/README.md            <- COMMENT obtenir et préparer la base d'images
└── docs/GLOSSAIRE.md         <- tous les mots techniques expliqués
```

## 2. Installation (une seule fois)

1. Installer **Python 3.10 ou plus récent** (python.org ; sous Windows cocher « Add Python to PATH »).
2. Ouvrir un terminal dans le dossier du dépôt, puis :
```bash
python -m venv venv
# Windows :        venv\Scripts\activate
# Mac / Linux :    source venv/bin/activate
pip install -r requirements.txt
python scripts/check_setup.py
```
`venv` est un « espace propre » où s'installent les outils, sans abîmer le reste de l'ordinateur.
`check_setup.py` affiche `[OK]` pour chaque outil et dit si vous avez un GPU.

## 3. Premier test (5 minutes, sans données, sans modèle, sans drone)

```bash
python scripts/run_detection.py --weights none --source synthetic --thermal synthetic --gas sim --fire-after 4 --max-seconds 16
python scripts/make_map.py
```
Que se passe-t-il ? Le programme **simule** une caméra thermique : une conduite chaude normale (≈ 95 °C, ignorée), puis un foyer
(≈ 480 °C) apparaît après 4 s, avec une hausse de gaz. Vous verrez dans le terminal une alerte `A_VERIFIER` puis `ALERTE`
avec la position estimée du foyer. Ouvrez `alerts/map.html` dans un navigateur : cercles **rouge** (zone à éviter), **orange**
(à vérifier) et marge d'incertitude **bleue**. Ajoutez `--show` pour voir la fenêtre vidéo.

Vérification automatique de la logique :
```bash
python -m unittest discover -s tests -v
```

## 4. Préparer les données

Lisez **`data/README.md`** (sources : D-Fire, Roboflow, FLAME, vos images ; images négatives ; annotation). Puis :
```bash
python scripts/prepare_dataset.py --source raw/DFire="smoke,fire" --negatives raw/negatives --out dataset
```
Cela crée `dataset/` (train 70 % / val 20 % / test 10 %) et `data.yaml`. **Copiez le tableau affiché dans votre rapport.**

## 5. Entraîner le modèle

**Sans carte graphique NVIDIA : utilisez Google Colab** → ouvrez `notebooks/train_colab.ipynb` sur colab.research.google.com
(Fichier → Importer un notebook) et suivez les cellules. Avec un GPU local :
```bash
python scripts/train.py --model yolov8n.pt --epochs 100 --batch 16 --device 0
```
Le modèle final est `runs_fire/yolov8n_fire/weights/best.pt` (**sauvegardez-le**). Les courbes sont dans `runs_fire/yolov8n_fire/`
(`results.png`, `confusion_matrix.png`, `PR_curve.png`) : ce sont des figures pour le rapport.
Options : `--model yolov8s.pt` (plus précis, plus lent), `--epochs 50` (test rapide), `--resume` (reprendre après une coupure).

## 6. Évaluer (les chiffres du rapport)

```bash
python scripts/evaluate.py --weights runs_fire/yolov8n_fire/weights/best.pt --negatives raw/negatives_test
```
Résultat dans `reports/metrics.json` : mAP, précision, rappel (par classe), vitesse (ms/image, FPS) et **taux de fausses alertes**
sur des images sans feu. Gardez de côté des images négatives que le modèle n'a **jamais** vues pour ce test.

## 7. Utiliser le modèle (pipeline complet)

```bash
# sur une vidéo, avec thermique et gaz simulés
python scripts/run_detection.py --weights runs_fire/yolov8n_fire/weights/best.pt --source ma_video.mp4 --thermal synthetic --gas sim --show --save-video sortie.mp4
# webcam
python scripts/run_detection.py --weights best.pt --source 0 --show
```
Pour une vraie caméra thermique, exportez les images en fichiers `.npy` (tableau de températures en °C) et utilisez `--thermal dossier_npy`.

### Comment une alerte est décidée (en clair)
1. Chaque source donne une note entre 0 et 1 : caméra (confiance de l'IA), thermique (température), gaz (%LIE).
2. Les notes sont combinées (poids dans `configs/flamex.yaml`). Si une source manque, on renormalise.
3. **A_VERIFIER (orange)** : score ≥ 0,35 pendant au moins 2 images. **ALERTE (rouge)** : score ≥ 0,60, **deux sources au moins**
   (ou caméra très sûre ≥ 0,85), pendant **5 images de suite**. Cela évite les fausses alertes d'une image isolée.
4. Une chaleur seule (conduite à 95 °C) n'est jamais une alerte : *chaleur ≠ incendie*.
5. Si le point est dans une zone connue (`known_zones`, ex. torche), l'alerte rouge est rétrogradée en « à vérifier ».

### Comment la position du foyer est calculée
Le GPS donne la position du **drone**, pas du feu. Le programme prend le pixel du feu, la hauteur du drone, son cap et
l'inclinaison de la caméra, trace un rayon jusqu'au sol et en déduit les coordonnées, avec une **marge d'incertitude**
(erreurs GPS, cap, angle, altitude). **Limite :** hypothèse de sol plat ; près de structures hautes, l'erreur augmente.

## 8. Brancher un vrai drone (plus tard)
- Dans `configs/flamex.yaml` : `telemetry.mode: mavlink` + la connexion (`udp:127.0.0.1:14550` ou `/dev/ttyAMA0`) + `pip install pymavlink`.
- Renseigner `camera.hfov_deg` (champ de vision de la caméra, fiche technique) et les erreurs de `uncertainty`.
- Sur ordinateur embarqué (Jetson / Raspberry Pi) : exporter le modèle (`yolo export model=best.pt format=onnx`, `engine` pour Jetson, `ncnn` pour Raspberry Pi).
- Gaz : utiliser des détecteurs **certifiés ATEX validés par le site** ; ne jamais faire voler un équipement non certifié en zone explosive.

## 9. Publier sur GitHub (pas à pas)
1. Créer un compte sur github.com, puis **New repository** → nom `flame-x-ai` → *Create repository* (sans cocher README).
2. Installer **git** (git-scm.com). Dans le dossier du projet :
```bash
git init
git add .
git commit -m "Prototype FLAME-X"
git branch -M main
git remote add origin https://github.com/VOTRE_COMPTE/flame-x-ai.git
git push -u origin main
```
(GitHub demande de se connecter ; un « token d'accès personnel » remplace le mot de passe.)
Les images, modèles (`.pt`) et résultats sont ignorés (`.gitignore`) car trop lourds : gardez-les sur Google Drive.

## 10. Problèmes fréquents
| Message / symptôme | Cause et solution |
|---|---|
| `python` n'est pas reconnu | Python non installé ou pas dans le PATH ; essayez `python3` ou `py`. |
| `ModuleNotFoundError: ultralytics` | Le venv n'est pas activé ou `pip install -r requirements.txt` oublié. |
| L'entraînement est extrêmement lent | Pas de GPU → utiliser Colab (`notebooks/train_colab.ipynb`). |
| `CUDA out of memory` | Réduire `--batch 8` (ou 4). |
| `Aucune image trouvée` à la préparation | Vérifier les chemins `--source` et la présence des labels `.txt`. |
| Beaucoup de fausses alertes | Ajouter des images négatives (torches, vapeur, lumières), augmenter `confirm_frames` ou `--conf`. |
| Des feux ratés | Ajouter des images de ce type de scène ; baisser `vision.conf` ; vérifier le rappel avec `evaluate.py`. |
| La carte est vide / grise | `make_map.py` après une exécution qui a produit une alerte ; connexion internet requise pour le fond de carte. |

## 11. Limites et sécurité
- Prototype de recherche : **aucune performance n'est garantie**. Elles sont **mesurées** (voir le rapport), jamais supposées.
- Ne jamais allumer de feu non encadré. Tests réels uniquement en exercice autorisé (pompiers, sécurité du site).
- Les itinéraires d'évacuation (« vert ») ne sont **pas** calculés ici : ils exigent le plan du site, le vent, les zones classées et la validation du centre de contrôle / de la protection civile.
- L'appel automatique aux secours est volontairement **absent** (accord officiel + canal autorisé + garde-fous requis).
- Respecter la réglementation aérienne et les règles ATEX / sûreté de la raffinerie.

## 12. Pistes d'amélioration
Caméra thermique radiométrique complète et alignement RGB/thermique ; segmentation de la fumée ; suivi des objets dans le temps ;
élévation du terrain (MNT) pour la localisation ; vent et propagation ; itinéraires sur plan SIG ; apprentissage continu avec les
fausses alertes ; classe `flare` dédiée ; export TensorRT ; essaim de drones.

## Licence
Code sous licence MIT (`LICENSE`). La bibliothèque **ultralytics** (YOLOv8) est sous licence **AGPL-3.0** : vérifier ses conditions pour un usage commercial.
