"""Entrainement YOLOv8 pour la detection de feu / fumee.
Exemple (depuis la racine du depot) : python scripts/train.py --model yolov8n.pt --epochs 100 --batch 16 --device 0
"""
import argparse
from ultralytics import YOLO


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data.yaml")
    ap.add_argument("--model", default="yolov8n.pt", help="yolov8n/s/m.pt (ou yolo11n.pt)")
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--imgsz", type=int, default=640)
    ap.add_argument("--batch", type=int, default=16)
    ap.add_argument("--device", default=None, help="0 pour GPU, cpu pour CPU")
    ap.add_argument("--name", default="yolov8n_fire")
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()

    model = YOLO(args.model)
    model.train(
        data=args.data, epochs=args.epochs, imgsz=args.imgsz, batch=args.batch,
        device=args.device, patience=20, project="runs_fire", name=args.name,
        # augmentations adaptees a la vue aerienne
        hsv_h=0.015, hsv_s=0.7, hsv_v=0.4, degrees=10, flipud=0.5, fliplr=0.5,
        mosaic=1.0, scale=0.5, translate=0.1, resume=args.resume, plots=True,
    )

    m = model.val(data=args.data, split="test", device=args.device)
    print(f"\n=== TEST === mAP50={m.box.map50:.3f}  mAP50-95={m.box.map:.3f}  "
          f"Precision={m.box.mp:.3f}  Rappel={m.box.mr:.3f}")
    for i, name in model.names.items():
        print(f"  {name}: AP50={m.box.ap50[i]:.3f}")

    model.export(format="onnx", imgsz=args.imgsz)   # "engine" (TensorRT) sur Jetson, "ncnn" sur Raspberry Pi
    print("Poids : runs_fire/%s/weights/best.pt" % args.name)


if __name__ == "__main__":
    main()
