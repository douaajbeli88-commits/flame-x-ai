"""
Fusionne un ou plusieurs datasets au format YOLO, harmonise les classes
(fire = 0, smoke = 1), puis cree dataset/{images,labels}/{train,val,test} + data.yaml.

Lancer depuis la racine du depot : python scripts/prepare_dataset.py ...

ASTUCE RAFFINERIE : mettez dans --negatives des images de TORCHES (flares) normales, de tuyauteries
chaudes, de coucher de soleil, de lumieres orange... pour apprendre au modele ce qui n est PAS un incendie.

Exemples :
  # D-Fire (classes: 0=smoke, 1=fire) + un export Roboflow (lit son data.yaml)
  python scripts/prepare_dataset.py \
      --source raw/DFire="smoke,fire" \
      --source raw/roboflow_fire \
      --negatives raw/negatives \
      --out dataset

Format --source :  CHEMIN            -> les noms de classes sont lus dans CHEMIN/data.yaml
                   CHEMIN=nom0,nom1  -> noms de classes (dans l'ordre des indices 0,1,...)
"""
import argparse
import random
import shutil
from collections import Counter
from pathlib import Path

import yaml

IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}
TARGET = {"fire": 0, "smoke": 1}
ALIASES = {"fire": "fire", "flame": "fire", "flames": "fire", "feu": "fire",
           "smoke": "smoke", "fumee": "smoke", "fumée": "smoke"}


def parse_source(spec):
    if "=" in spec:
        path, names = spec.split("=", 1)
        names = [n.strip().lower() for n in names.split(",")]
    else:
        path, names = spec, None
    path = Path(path)
    if names is None:
        yml = next(iter(path.rglob("data.yaml")), None)
        if yml is None:
            raise SystemExit(f"[ERREUR] Pas de data.yaml dans {path}. Utilisez CHEMIN=nom0,nom1")
        raw = yaml.safe_load(yml.read_text(encoding="utf-8"))["names"]
        names = [raw[k] for k in sorted(raw)] if isinstance(raw, dict) else list(raw)
        names = [str(n).lower() for n in names]
    return path, names


def find_label(img: Path):
    parts = list(img.parts)
    for i in range(len(parts) - 1, -1, -1):          # remplace le dernier dossier "images" par "labels"
        if parts[i].lower() == "images":
            parts[i] = "labels"
            cand = Path(*parts).with_suffix(".txt")
            if cand.exists():
                return cand
            break
    same = img.with_suffix(".txt")
    return same if same.exists() else None


def remap_label(txt_path, names):
    """Retourne les lignes YOLO avec les classes harmonisees (classes inconnues ignorees)."""
    out = []
    if txt_path is None:
        return out
    for line in txt_path.read_text().splitlines():
        p = line.split()
        if len(p) < 5:
            continue
        idx = int(float(p[0]))
        if idx >= len(names):
            continue
        target = ALIASES.get(names[idx])
        if target is None:
            continue
        out.append(" ".join([str(TARGET[target])] + p[1:]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--source", action="append", required=True)
    ap.add_argument("--negatives", default=None, help="dossier d'images SANS feu (labels vides)")
    ap.add_argument("--out", default="dataset")
    ap.add_argument("--split", default="0.7,0.2,0.1", help="train,val,test")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--keep-unlabeled", action="store_true",
                    help="garder comme negatifs les images sans fichier label")
    args = ap.parse_args()

    items = []  # (image_path, lignes_label, prefixe)
    for i, spec in enumerate(args.source):
        path, names = parse_source(spec)
        print(f"[INFO] Source {i}: {path} classes={names}")
        n = 0
        for img in path.rglob("*"):
            if img.suffix.lower() not in IMG_EXT:
                continue
            lab = find_label(img)
            if lab is None and not args.keep_unlabeled:
                continue
            items.append((img, remap_label(lab, names), f"s{i}"))
            n += 1
        print(f"       -> {n} images retenues")

    if args.negatives:
        k = 0
        for img in Path(args.negatives).rglob("*"):
            if img.suffix.lower() in IMG_EXT:
                items.append((img, [], "neg"))
                k += 1
        print(f"[INFO] {k} images negatives ajoutees")

    if not items:
        raise SystemExit("[ERREUR] Aucune image trouvee.")

    random.seed(args.seed)
    random.shuffle(items)
    r = [float(x) for x in args.split.split(",")]
    n = len(items)
    n_tr, n_va = int(n * r[0]), int(n * r[1])
    splits = {"train": items[:n_tr], "val": items[n_tr:n_tr + n_va], "test": items[n_tr + n_va:]}

    out = Path(args.out)
    if out.exists():
        shutil.rmtree(out)
    for name, subset in splits.items():
        (out / "images" / name).mkdir(parents=True)
        (out / "labels" / name).mkdir(parents=True)
        counts = Counter()
        for j, (img, lines, pref) in enumerate(subset):
            stem = f"{pref}_{j:06d}"
            shutil.copy2(img, out / "images" / name / f"{stem}{img.suffix.lower()}")
            (out / "labels" / name / f"{stem}.txt").write_text("\n".join(lines))
            for ln in lines:
                counts[int(ln.split()[0])] += 1
        print(f"[{name:5}] {len(subset):6d} images | fire={counts[0]} smoke={counts[1]} "
              f"| sans objet={sum(1 for _, l, _ in subset if not l)}")

    data = {"path": str(out.resolve()), "train": "images/train", "val": "images/val",
            "test": "images/test", "names": {0: "fire", 1: "smoke"}}
    Path("data.yaml").write_text(yaml.dump(data, allow_unicode=True, sort_keys=False))
    print("[OK] dataset pret + data.yaml ecrit")


if __name__ == "__main__":
    main()
