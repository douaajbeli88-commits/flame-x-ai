"""Extrait des images d'une video (pour creer vos propres images a annoter ou des images negatives).
Exemple : python scripts/extract_frames.py --video flare.mp4 --out raw/negatives --every 2
(une image toutes les 2 secondes)
"""
import argparse
from pathlib import Path

import cv2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--video", required=True)
    ap.add_argument("--out", required=True)
    ap.add_argument("--every", type=float, default=2.0, help="secondes entre deux images")
    ap.add_argument("--prefix", default=None)
    args = ap.parse_args()

    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        raise SystemExit(f"[ERREUR] Impossible d'ouvrir {args.video}")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    step = max(1, int(round(fps * args.every)))
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    prefix = args.prefix or Path(args.video).stem
    i = saved = 0
    while True:
        ok, frame = cap.read()
        if not ok:
            break
        if i % step == 0:
            cv2.imwrite(str(out / f"{prefix}_{i:06d}.jpg"), frame)
            saved += 1
        i += 1
    cap.release()
    print(f"[OK] {saved} images enregistrees dans {out}")


if __name__ == "__main__":
    main()
