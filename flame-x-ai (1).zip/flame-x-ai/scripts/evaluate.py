"""Evalue le modele entraine : precision, rappel, mAP, vitesse, et taux de fausses alertes.

Exemples (depuis la racine du depot) :
  python scripts/evaluate.py --weights runs_fire/yolov8n_fire/weights/best.pt
  python scripts/evaluate.py --weights best.pt --negatives raw/negatives_test --conf 0.35
Les resultats sont enregistres dans reports/metrics.json (a copier dans votre rapport).
"""
import argparse
import json
import time
from pathlib import Path

import yaml
from ultralytics import YOLO

IMG_EXT = {".jpg", ".jpeg", ".png", ".bmp", ".webp"}


def list_images(folder):
    return sorted(p for p in Path(folder).rglob("*") if p.suffix.lower() in IMG_EXT)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", required=True)
    ap.add_argument("--data", default="data.yaml")
    ap.add_argument("--split", default="test")
    ap.add_argument("--device", default=None)
    ap.add_argument("--bench-images", type=int, default=50, help="nb d'images pour mesurer la vitesse")
    ap.add_argument("--negatives", default=None, help="dossier d'images SANS feu (mesure des fausses alertes)")
    ap.add_argument("--conf", type=float, default=0.35, help="seuil de confiance pour les fausses alertes")
    ap.add_argument("--out", default="reports/metrics.json")
    args = ap.parse_args()

    model = YOLO(args.weights)
    m = model.val(data=args.data, split=args.split, device=args.device, plots=True)
    report = {
        "weights": args.weights, "split": args.split,
        "mAP50": float(m.box.map50), "mAP50_95": float(m.box.map),
        "precision": float(m.box.mp), "recall": float(m.box.mr), "per_class": {},
    }
    for i, c in enumerate(m.box.ap_class_index):
        report["per_class"][model.names[int(c)]] = {
            "AP50": float(m.box.ap50[i]), "precision": float(m.box.p[i]), "recall": float(m.box.r[i])}

    # --- vitesse ---
    cfg = yaml.safe_load(open(args.data, encoding="utf-8"))
    test_dir = Path(cfg["path"]) / cfg[args.split]
    imgs = list_images(test_dir)[: args.bench_images]
    if imgs:
        for p in imgs[:3]:                                   # echauffement
            model.predict(str(p), verbose=False)
        times = []
        for p in imgs:
            r = model.predict(str(p), verbose=False, device=args.device)[0]
            times.append(sum(r.speed.values()))
        avg = sum(times) / len(times)
        report["speed"] = {"images": len(imgs), "avg_ms_per_image": round(avg, 1), "fps": round(1000 / avg, 1)}

    # --- fausses alertes sur images sans feu ---
    if args.negatives:
        neg = list_images(args.negatives)
        false_pos = 0
        for p in neg:
            r = model.predict(str(p), conf=args.conf, verbose=False, device=args.device)[0]
            false_pos += int(len(r.boxes) > 0)
        report["false_alarms"] = {"negative_images": len(neg), "images_with_detection": false_pos,
                                  "rate": round(false_pos / max(1, len(neg)), 4), "conf": args.conf}

    Path(args.out).parent.mkdir(parents=True, exist_ok=True)
    Path(args.out).write_text(json.dumps(report, indent=2, ensure_ascii=False))
    print(json.dumps(report, indent=2, ensure_ascii=False))
    print(f"\n[OK] Resultats enregistres dans {args.out} (courbes et matrice de confusion dans runs/detect/val*)")


if __name__ == "__main__":
    main()
