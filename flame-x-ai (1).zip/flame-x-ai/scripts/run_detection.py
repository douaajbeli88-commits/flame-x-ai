"""FLAME-X : pipeline complet  camera (IA) + thermique + gaz -> score -> localisation -> alerte.

Exemples (depuis la racine du depot) :
  # 1) Demo SANS modele, SANS drone : tout est simule (a lancer en premier pour verifier l'installation)
  python scripts/run_detection.py --weights none --source synthetic --thermal synthetic --gas sim

  # 2) Modele entraine sur une video, avec thermique et gaz simules
  python scripts/run_detection.py --weights runs_fire/yolov8n_fire/weights/best.pt --source video.mp4 \
      --thermal synthetic --gas sim --show --save-video sortie.mp4

  # 3) Vrai drone (MAVLink) : mettre telemetry.mode: mavlink dans configs/flamex.yaml
  python scripts/run_detection.py --weights best.pt --source 0 --thermal DOSSIER_NPY
"""
import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import cv2
import numpy as np

from flamex.alerts import AlertManager
from flamex.config import load_config
from flamex.fusion import A_VERIFIER, ALERTE, NORMAL, Evidence, FusionEngine
from flamex.geolocation import estimate_uncertainty_m, match_known_zone, project_pixel
from flamex.sensors import make_gas_source
from flamex.telemetry import make_telemetry
from flamex.thermal import ThermalSource, ThermalTrend, detect_hotspots

COLORS = {NORMAL: (0, 200, 0), A_VERIFIER: (0, 140, 255), ALERTE: (0, 0, 255)}   # BGR


def run_vision(model, frame, conf, imgsz):
    """Retourne (conf_feu, conf_fumee, cible(cx, cy, nom, conf) ou None, image annotee)."""
    if model is None:
        return 0.0, 0.0, None, frame.copy()
    res = model(frame, conf=conf, imgsz=imgsz, verbose=False)[0]
    best = {"fire": None, "smoke": None}
    for b in res.boxes:
        name, c = res.names[int(b.cls)], float(b.conf)
        if name in best and (best[name] is None or c > best[name][3]):
            x1, y1, x2, y2 = b.xyxy[0].tolist()
            best[name] = ((x1 + x2) / 2, (y1 + y2) / 2, name, c)
    fire = best["fire"][3] if best["fire"] else 0.0
    smoke = best["smoke"][3] if best["smoke"] else 0.0
    target = best["fire"] or best["smoke"]
    return fire, smoke, target, res.plot()


def blank_frame(w=960, h=540):
    f = np.full((h, w, 3), 45, np.uint8)
    cv2.putText(f, "FLAME-X - image synthetique (demo)", (30, 50), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (200, 200, 200), 2)
    return f


def draw_overlay(img, decision, ev, pose, hotspots, thermal_shape, fps):
    h, w = img.shape[:2]
    color = COLORS[decision.level]
    cv2.rectangle(img, (0, 0), (w - 1, h - 1), color, 6)
    if thermal_shape is not None:
        th, tw = thermal_shape
        for hs in hotspots:
            p1 = (int(hs.x * w / tw), int(hs.y * h / th))
            p2 = (int((hs.x + hs.w) * w / tw), int((hs.y + hs.h) * h / th))
            cv2.rectangle(img, p1, p2, (0, 165, 255), 2)
            cv2.putText(img, f"{hs.max_c:.0f}C", (p1[0], max(15, p1[1] - 5)), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 165, 255), 1)
    cv2.rectangle(img, (0, h - 70), (w, h), (20, 20, 20), -1)
    cv2.putText(img, f"{decision.level}  score={decision.score:.2f}  FPS={fps:.0f}", (10, h - 45),
                cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
    txt = f"cam f={ev.fire_conf:.2f} s={ev.smoke_conf:.2f}"
    if ev.thermal_max_c is not None:
        txt += f" | therm={ev.thermal_max_c:.0f}C"
    if ev.gas_lel_pct is not None:
        txt += f" | gaz={ev.gas_lel_pct:.1f}%LIE"
    cv2.putText(img, txt, (10, h - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (230, 230, 230), 1)
    return img


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--weights", required=True, help="chemin du modele .pt, ou 'none' pour tester sans modele")
    ap.add_argument("--source", default="synthetic", help="index camera, fichier video, URL RTSP ou 'synthetic'")
    ap.add_argument("--thermal", default="none", help="none | synthetic | dossier ou fichier .npy (degres C)")
    ap.add_argument("--gas", default="none", choices=["none", "sim"])
    ap.add_argument("--config", default="configs/flamex.yaml")
    ap.add_argument("--fire-after", type=float, default=8.0, help="(simulation) secondes avant l'apparition du foyer")
    ap.add_argument("--max-seconds", type=float, default=None)
    ap.add_argument("--show", action="store_true")
    ap.add_argument("--save-video", default=None)
    args = ap.parse_args()

    cfg = load_config(args.config)
    model = None
    if args.weights.lower() != "none":
        from ultralytics import YOLO
        model = YOLO(args.weights)

    synthetic = args.source == "synthetic"
    cap = None
    if not synthetic:
        cap = cv2.VideoCapture(int(args.source) if args.source.isdigit() else args.source)
        if not cap.isOpened():
            raise SystemExit(f"[ERREUR] Impossible d'ouvrir la source : {args.source}")
    max_s = args.max_seconds if args.max_seconds is not None else (25.0 if synthetic else None)

    fusion = FusionEngine(cfg)
    thermal_src = ThermalSource(args.thermal, args.fire_after)
    trend = ThermalTrend(delta_c=cfg["thermal"]["trend_delta_c"])
    gas_src = make_gas_source(args.gas, args.fire_after)
    telem = make_telemetry(cfg)
    alerts = AlertManager(cfg)
    hfov, unc = cfg["camera"]["hfov_deg"], cfg["uncertainty"]

    writer, idx, t0, t_prev, last_trend = None, 0, time.time(), time.time(), -1e9
    print("FLAME-X demarre. Appuyez sur 'q' dans la fenetre (ou Ctrl+C) pour arreter.")
    try:
        while True:
            if synthetic:
                frame = blank_frame()
                time.sleep(1 / 15)
            else:
                ok, frame = cap.read()
                if not ok:
                    break
            t_frame = time.time()
            t = t_frame - t0
            if max_s and t > max_s:
                break
            h, w = frame.shape[:2]

            fire, smoke, vtarget, annotated = run_vision(model, frame, cfg["vision"]["conf"], cfg["vision"]["imgsz"])

            temp, hotspots, tmax = thermal_src.read(idx, t), [], None
            if temp is not None:
                hotspots = detect_hotspots(temp, cfg["thermal"]["hotspot_min_c"], cfg["thermal"]["min_area_px"])
                tmax = float(temp.max())
                anomalies = trend.update(temp)
                if anomalies and t - last_trend > 30:
                    a = anomalies[0]
                    print(f"[PREVENTION] hausse inhabituelle de temperature : {a['baseline_c']:.0f} -> {a['current_c']:.0f} C (zone {a['cell']})")
                    last_trend = t

            gas = gas_src.read(t) if gas_src else None
            ev = Evidence(fire, smoke, tmax, gas, vision_available=model is not None)
            decision = fusion.update(ev)

            fps = 1.0 / max(t_frame - t_prev, 1e-6)
            t_prev = t_frame
            tshape = temp.shape if temp is not None else None
            annotated = draw_overlay(annotated, decision, ev, telem.get() or _dummy(cfg), hotspots, tshape, fps)

            if decision.level != NORMAL and alerts.should_emit(decision.level, t_frame):
                pose = telem.get()
                if pose is None:
                    print("[ALERTE] position du drone indisponible : alerte non enregistree")
                else:
                    ground, uncertainty, kind, notes = None, 0.0, "aucune", []
                    pix = None
                    if vtarget:
                        pix, kind = (vtarget[0], vtarget[1]), f"camera:{vtarget[2]}"
                    elif hotspots:
                        hs = hotspots[0]
                        pix, kind = (hs.cx * w / tshape[1], hs.cy * h / tshape[0]), "thermique"
                    if pix is None:
                        pix, kind = (w / 2, h / 2), "centre_image"
                        notes.append("aucun objet localise : centre de l'image utilise")
                    ground = project_pixel(pose, pix[0], pix[1], w, h, hfov)
                    if ground:
                        uncertainty = estimate_uncertainty_m(pose, pix[0], pix[1], w, h, hfov, unc["gps_m"],
                                                             unc["heading_deg"], unc["pitch_deg"], unc["alt_m"])
                        zone = match_known_zone(ground.lat, ground.lon, cfg.get("known_zones"))
                        if zone:
                            notes.append(f"zone connue : {zone} (torche / zone chaude normale ?)")
                            if decision.level == ALERTE:
                                decision.level = A_VERIFIER
                    else:
                        notes.append("le regard de la camera ne touche pas le sol : position du drone utilisee")
                    alerts.emit(decision, annotated, pose, ground, uncertainty, kind, notes, (time.time() - t_frame) * 1000)

            if args.save_video:
                if writer is None:
                    writer = cv2.VideoWriter(args.save_video, cv2.VideoWriter_fourcc(*"mp4v"), 15, (w, h))
                writer.write(annotated)
            if args.show:
                cv2.imshow("FLAME-X (q = quitter)", annotated)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
            idx += 1
    except KeyboardInterrupt:
        pass
    finally:
        if cap:
            cap.release()
        if writer:
            writer.release()
        cv2.destroyAllWindows()
    print(f"\nTermine : {idx} images traitees, {alerts.count} alerte(s) enregistree(s) dans '{alerts.dir}/'.")
    if alerts.count:
        print("Pour voir la carte :  python scripts/make_map.py")


def _dummy(cfg):
    from flamex.geolocation import Pose
    return Pose(0, 0, 0, 0, 0)


if __name__ == "__main__":
    main()
