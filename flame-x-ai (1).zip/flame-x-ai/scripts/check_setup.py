"""Verifie que l'installation est correcte. Lancer : python scripts/check_setup.py"""
import importlib
import platform
import sys

print("Python :", sys.version.split()[0], "|", platform.system())
for name in ["numpy", "cv2", "yaml", "ultralytics", "torch", "pymavlink"]:
    try:
        m = importlib.import_module(name)
        print(f"  [OK]       {name} {getattr(m, '__version__', '')}")
    except Exception:
        optional = " (optionnel)" if name == "pymavlink" else ""
        print(f"  [MANQUANT] {name}{optional}  -> pip install -r requirements.txt")

try:
    import torch
    if torch.cuda.is_available():
        print("GPU detecte :", torch.cuda.get_device_name(0), "-> utilisez --device 0")
    else:
        print("Pas de GPU : l'entrainement sera LENT. Utilisez Google Colab (voir notebooks/train_colab.ipynb).")
except Exception:
    pass
