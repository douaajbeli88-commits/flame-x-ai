"""Genere une carte interactive (HTML) des alertes : zones rouges / oranges et marge d'incertitude.
Usage : python scripts/make_map.py   puis ouvrir alerts/map.html dans un navigateur (internet requis pour le fond de carte).
ATTENTION : ce prototype ne calcule PAS d'itineraire vert : il faut le plan du site, le vent et la
validation du centre de controle / de la protection civile (voir le rapport).
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from flamex.config import load_config

HTML = """<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8"><title>FLAME-X - carte des alertes</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css">
<style>
 html,body{height:100%;margin:0;font-family:Arial,sans-serif}
 #map{height:100%}
 .legend{background:#fff;padding:8px 10px;border-radius:6px;line-height:1.5;font-size:13px;box-shadow:0 1px 5px rgba(0,0,0,.4)}
 .dot{display:inline-block;width:12px;height:12px;border-radius:50%;margin-right:6px}
</style></head><body><div id="map"></div>
<script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
<script>
const data = __DATA__;
const cfg = __CFG__;
const map = L.map('map');
L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {maxZoom: 19, attribution: '&copy; OpenStreetMap'}).addTo(map);
const pts = [];
data.features.forEach(f => {
  const p = f.properties, lat = f.geometry.coordinates[1], lon = f.geometry.coordinates[0];
  const red = p.level === 'ALERTE', color = red ? '#e53935' : '#fb8c00';
  L.circle([lat, lon], {radius: red ? cfg.avoid_radius_m : cfg.uncertain_radius_m, color: color, weight: 1, fillOpacity: 0.15}).addTo(map);
  if (p.uncertainty_m > 0) L.circle([lat, lon], {radius: p.uncertainty_m, color: '#1e88e5', dashArray: '4', fill: false, weight: 2}).addTo(map);
  L.circleMarker([lat, lon], {radius: 8, color: color, fillColor: color, fillOpacity: 1})
    .bindPopup('<b>' + p.level + '</b> (' + p.id + ')<br>score : ' + p.score + '<br>heure : ' + p.time +
               '<br>position : ' + p.position_type + ' &plusmn;' + p.uncertainty_m + ' m<br>' + p.reasons.join('<br>'))
    .addTo(map);
  pts.push([lat, lon]);
  const d = p.drone;
  L.marker([d.lat, d.lon]).bindPopup('Drone (' + d.alt_agl_m + ' m, cap ' + d.heading_deg + ')').addTo(map);
  pts.push([d.lat, d.lon]);
});
(cfg.known_zones || []).forEach(z => {
  L.circle([z.lat, z.lon], {radius: z.radius_m, color: '#6d4c41', dashArray: '2', fillOpacity: 0.05}).bindPopup(z.name).addTo(map);
  pts.push([z.lat, z.lon]);
});
if (pts.length) map.fitBounds(pts, {padding: [40, 40], maxZoom: 18}); else map.setView(cfg.center, 16);
const legend = L.control({position: 'bottomleft'});
legend.onAdd = () => { const d = L.DomUtil.create('div', 'legend');
  d.innerHTML = '<span class="dot" style="background:#e53935"></span>Zone a eviter (alerte)<br>' +
    '<span class="dot" style="background:#fb8c00"></span>A verifier<br>' +
    '<span class="dot" style="background:#1e88e5"></span>Marge d incertitude<br>' +
    '<span class="dot" style="background:#6d4c41"></span>Zone connue (torche...)<br>' +
    '<i>Itineraire : a valider par le centre de controle</i>'; return d; };
legend.addTo(map);
</script></body></html>
"""


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="configs/flamex.yaml")
    ap.add_argument("--geojson", default=None)
    ap.add_argument("--out", default=None)
    args = ap.parse_args()
    cfg = load_config(args.config)
    adir = Path(cfg["alerts"]["dir"])
    gj = Path(args.geojson) if args.geojson else adir / "events.geojson"
    data = json.loads(gj.read_text(encoding="utf-8")) if gj.exists() else {"type": "FeatureCollection", "features": []}
    fx = cfg["telemetry"]["fixed"]
    js_cfg = {"avoid_radius_m": cfg["map"]["avoid_radius_m"], "uncertain_radius_m": cfg["map"]["uncertain_radius_m"],
              "known_zones": cfg.get("known_zones") or [], "center": [fx["lat"], fx["lon"]]}
    html = HTML.replace("__DATA__", json.dumps(data)).replace("__CFG__", json.dumps(js_cfg))
    out = Path(args.out) if args.out else adir / "map.html"
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(html, encoding="utf-8")
    print(f"[OK] {len(data['features'])} evenement(s) -> {out}")


if __name__ == "__main__":
    main()
