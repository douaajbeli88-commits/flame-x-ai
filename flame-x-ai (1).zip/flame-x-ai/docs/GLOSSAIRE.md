# Glossaire (pour débutants)

| Mot | Explication simple |
|---|---|
| **IA / modèle** | Un programme qui a *appris* à reconnaître quelque chose à partir d'exemples, au lieu de suivre des règles écrites à la main. |
| **Réseau de neurones** | Le type de « cerveau » utilisé : une grande suite de calculs dont les réglages (millions de nombres) sont ajustés pendant l'entraînement. |
| **YOLO** | « You Only Look Once » : famille de modèles qui trouvent des objets dans une image **en un seul passage**, donc très rapides. |
| **Détection d'objets** | Dire *quoi* est dans l'image et *où* (un rectangle autour). |
| **Dataset** | La collection d'images + annotations utilisée pour apprendre. |
| **Annotation / label** | Le rectangle (et le nom) dessiné autour de chaque feu ou fumée. |
| **Entraînement** | La phase où le modèle regarde les images d'apprentissage et ajuste ses réglages pour se tromper moins. |
| **Epoch** | Un passage complet sur toutes les images d'entraînement. 100 epochs = 100 révisions. |
| **Batch** | Le nombre d'images regardées ensemble à chaque étape. |
| **Poids (`best.pt`)** | Le fichier qui contient le « cerveau » entraîné. |
| **Apprentissage par transfert** | On part d'un modèle qui sait déjà reconnaître des objets (appris sur COCO) et on lui apprend seulement le feu : bien plus rapide. |
| **train / val / test** | Les 3 groupes d'images : exercices (train), contrôles pendant l'apprentissage (val), examen final jamais vu (test). |
| **Surapprentissage** | Le modèle apprend les images par cœur et échoue sur de nouvelles images. D'où le groupe *test*. |
| **Confiance** | Le nombre entre 0 et 1 que donne le modèle pour dire « je suis sûr à X % ». |
| **Précision** | Parmi les alertes données, la part qui sont de vrais feux (évite les fausses alertes). |
| **Rappel** | Parmi les vrais feux, la part que le modèle trouve (évite de rater un incendie). **Le plus important ici.** |
| **mAP@0.5** | Note globale (0 à 1) qui combine précision et rappel quand le rectangle recouvre au moins 50 % du vrai. |
| **Faux positif** | Fausse alerte (le modèle voit du feu, il n'y en a pas). |
| **Faux négatif** | Feu raté. |
| **Fusion de capteurs** | Combiner caméra, thermique et gaz pour décider mieux qu'avec un seul. |
| **Radiométrique** | Caméra thermique qui donne une **température** par pixel (pas seulement une image colorée). |
| **%LIE** | Pourcentage de la limite inférieure d'explosivité d'un gaz. 100 % LIE = mélange explosif. |
| **ATEX** | Certification des équipements autorisés en atmosphère explosive (obligatoire en raffinerie). |
| **GNSS / GPS** | Système de localisation par satellites. |
| **Cap (heading)** | Direction du nez du drone : 0° = nord, 90° = est. |
| **MAVLink** | Langage utilisé par les contrôleurs de vol (Pixhawk, ArduPilot, PX4) pour envoyer position et état. |
| **Géoréférencer** | Donner une position GPS à un point d'une image. |
| **GeoJSON** | Format de fichier standard pour des points sur une carte. |
| **ONNX / TensorRT / NCNN** | Formats d'export du modèle pour tourner vite sur un petit ordinateur embarqué. |
| **Jetson / Raspberry Pi** | Mini-ordinateurs que l'on peut embarquer sur le drone. |
| **GitHub** | Site pour stocker et partager du code ; **git** est l'outil qui enregistre les versions. |
