# Les données (base d'images) de FLAME-X

Une IA apprend à partir d'**exemples**. Ici, des images où l'on a entouré le feu et la fumée d'un rectangle
(on appelle cela *annoter*). Plus les images ressemblent à ce que verra le drone dans la raffinerie, meilleur sera le modèle.

## 1. Organisation des dossiers (à créer à la racine du dépôt)

```
raw/
├── DFire/            <- dataset D-Fire décompressé (images + labels)
├── roboflow_fire/    <- un export Roboflow (format YOLOv8)
├── mes_images/       <- vos propres images annotées (format YOLO)
└── negatives/        <- images SANS feu (voir plus bas, TRÈS important)
```
Le dossier `raw/` (données brutes) n'est jamais envoyé sur GitHub (il est dans `.gitignore`, les données sont trop lourdes).
Le script `scripts/prepare_dataset.py` lit `raw/` et fabrique `dataset/` + `data.yaml`.

## 2. D'où viennent les images ?

| Source | Contenu | Comment l'obtenir |
|---|---|---|
| **D-Fire** | ≈ 21 000 images annotées *feu* et *fumée*, déjà au format YOLO | GitHub : chercher `gaiasd/DFireDataset` ; le README donne le lien de téléchargement. Classes : `0 = smoke`, `1 = fire` |
| **Roboflow Universe** | Nombreux jeux de données annotés (feu, fumée, torche, incendie industriel) | universe.roboflow.com → chercher *fire smoke*, *flare stack*, *industrial fire*, *oil gas fire* → **Download Dataset** → format **YOLOv8** |
| **FLAME / FLAME 2** | Images de drone (RGB + thermique) de brûlages contrôlés en forêt | IEEE DataPort (chercher « FLAME dataset drone fire »). Utile pour la vue aérienne |
| **Kaggle** | Certains jeux « Fire Dataset », « Wildfire Smoke »… | Attention : souvent de la *classification* (dossiers fire / no_fire) **sans rectangles** : utilisables seulement comme images négatives ou à annoter |
| **Vos images** | Photos / vidéos libres de droits, vidéos de simulation, captures de votre drone d'essai | `python scripts/extract_frames.py --video ma_video.mp4 --out raw/mes_images_brutes --every 2` puis annoter |

**Honnêteté importante :** il n'existe pas (à notre connaissance) de grand jeu de données public spécifique aux
*raffineries*. La plupart sont des feux de forêt ou de bâtiments. Le prototype s'entraîne donc sur ces données
générales ; la **précision réelle dans une raffinerie devra être mesurée** sur des images de ce type d'environnement
(simulation, vidéos d'exercices autorisées) et le modèle ré-entraîné avec elles.
Vérifiez toujours la **licence** de chaque jeu de données avant de le réutiliser (surtout si le projet devient commercial).

## 3. Les images « négatives » : le point clé pour une raffinerie

Une raffinerie contient des choses qui **ressemblent** au feu mais n'en sont pas. Si le modèle ne les a jamais vues
comme « pas du feu », il donnera de fausses alertes. Ajoutez dans `raw/negatives/` des images de :

- **torches (flares) en fonctionnement normal** (flamme permanente en haut d'une cheminée) ;
- vapeur blanche des tours de refroidissement et des cheminées (≠ fumée d'incendie) ;
- tuyauteries chaudes, projecteurs, lumières orange, coucher de soleil, reflets sur le métal ;
- engins et équipements orange/rouge, vêtements de sécurité orange, panneaux de signalisation ;
- brume, nuages bas, poussière.

Règle pratique : viser au moins **15 à 30 % d'images sans feu** dans le dataset.
Complément indispensable : la liste `known_zones` de `configs/flamex.yaml` (positions GPS des torches).

## 4. Annoter ses propres images

Outils gratuits : **Roboflow** (en ligne, le plus simple), **CVAT**, **Label Studio**, **LabelImg**. Règles :

1. Un rectangle serré autour de **chaque** zone de flammes visibles → classe `fire`.
2. Un rectangle autour de chaque panache de fumée d'incendie → classe `smoke`.
3. **Ne pas annoter** une torche normale ni la vapeur : mettre l'image en négatif (fichier label vide).
4. Exporter au format **YOLO** (un fichier `.txt` par image : `classe x_centre y_centre largeur hauteur`, valeurs entre 0 et 1).
5. Mêmes règles pour tout le groupe : une personne qui relit les annotations des autres.

## 5. Combien d'images ?

Règles empiriques (pas des garanties) : un prototype correct se construit avec quelques milliers d'images annotées
(D-Fire seul suffit pour démarrer), complétées par quelques centaines d'images négatives propres au contexte industriel.
Mesurez ensuite : si le rappel est bas sur un type de scène, ajoutez des images *de ce type*.

## 6. Commande de préparation

```bash
python scripts/prepare_dataset.py \
  --source raw/DFire="smoke,fire" \
  --source raw/roboflow_fire \
  --negatives raw/negatives \
  --out dataset
```
`="smoke,fire"` indique l'ordre des classes dans la source (indice 0 puis indice 1). Pour un export Roboflow,
le `data.yaml` fourni est lu automatiquement, il n'y a rien à préciser.
Le script affiche le nombre d'images et d'objets par groupe (train / val / test) : **gardez cette sortie pour le rapport**.
