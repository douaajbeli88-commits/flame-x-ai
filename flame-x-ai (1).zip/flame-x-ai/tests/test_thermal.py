import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from flamex.thermal import ThermalTrend, detect_hotspots, make_synthetic_thermal


class TestThermal(unittest.TestCase):
    def test_detect_hotspot(self):
        img = make_synthetic_thermal(hotspots=[(0.5, 0.5, 10, 500.0)])
        hs = detect_hotspots(img, 150, min_area_px=4)
        self.assertEqual(len(hs), 1)
        self.assertGreater(hs[0].max_c, 400)
        self.assertAlmostEqual(hs[0].cx, 80, delta=3)

    def test_no_hotspot_on_warm_pipe(self):
        img = make_synthetic_thermal(hotspots=[(0.2, 0.7, 14, 95.0)])
        self.assertEqual(detect_hotspots(img, 150), [])

    def test_trend_detects_jump(self):
        tr = ThermalTrend(delta_c=25)
        calm = make_synthetic_thermal(hotspots=[(0.3, 0.3, 8, 60.0)], seed=1)
        for _ in range(8):
            self.assertEqual(tr.update(calm), [])
        hot = make_synthetic_thermal(hotspots=[(0.3, 0.3, 8, 140.0)], seed=1)
        self.assertTrue(len(tr.update(hot)) >= 1)


if __name__ == "__main__":
    unittest.main()
