import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from flamex.config import load_config
from flamex.fusion import A_VERIFIER, ALERTE, NORMAL, Evidence, FusionEngine

CFG = load_config(str(Path(__file__).resolve().parents[1] / "configs" / "flamex.yaml"))


def run(ev, n):
    eng, d = FusionEngine(CFG), None
    for _ in range(n):
        d = eng.update(ev)
    return d


class TestFusion(unittest.TestCase):
    def test_nothing(self):
        self.assertEqual(run(Evidence(), 10).level, NORMAL)

    def test_camera_alone_strong_gives_alert(self):
        self.assertEqual(run(Evidence(fire_conf=0.95), 6).level, ALERTE)

    def test_camera_alone_medium_only_verify(self):
        self.assertEqual(run(Evidence(fire_conf=0.6), 10).level, A_VERIFIER)

    def test_needs_confirmation_over_frames(self):
        eng = FusionEngine(CFG)
        levels = [eng.update(Evidence(fire_conf=0.95)).level for _ in range(6)]
        self.assertEqual(levels[0], NORMAL)
        self.assertEqual(levels[-1], ALERTE)

    def test_single_spike_does_not_alert(self):
        eng = FusionEngine(CFG)
        eng.update(Evidence(fire_conf=0.95))
        for _ in range(5):
            d = eng.update(Evidence())
        self.assertEqual(d.level, NORMAL)

    def test_thermal_and_gas_without_camera(self):
        ev = Evidence(thermal_max_c=450, gas_lel_pct=20, vision_available=False)
        self.assertEqual(run(ev, 6).level, ALERTE)

    def test_hot_equipment_alone_is_not_alert(self):
        ev = Evidence(thermal_max_c=95, vision_available=False)    # conduite chaude normale
        self.assertEqual(run(ev, 20).level, NORMAL)

    def test_thermal_only_hot_needs_second_source(self):
        ev = Evidence(thermal_max_c=500, vision_available=False)
        self.assertNotEqual(run(ev, 20).level, ALERTE)


if __name__ == "__main__":
    unittest.main()
