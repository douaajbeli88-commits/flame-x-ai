import math
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from flamex.geolocation import Pose, estimate_uncertainty_m, haversine_m, match_known_zone, project_pixel

W, H, FOV = 1280, 720, 70


class TestGeolocation(unittest.TestCase):
    def test_nadir_center_is_below_drone(self):
        g = project_pixel(Pose(36.8, 10.18, 100, 0, -90), W / 2, H / 2, W, H, FOV)
        self.assertAlmostEqual(g.distance_m, 0.0, places=3)
        self.assertAlmostEqual(g.lat, 36.8, places=6)

    def test_45_degrees_north(self):
        g = project_pixel(Pose(36.8, 10.18, 100, 0, -45), W / 2, H / 2, W, H, FOV)
        self.assertAlmostEqual(g.north_m, 100.0, places=2)
        self.assertAlmostEqual(g.east_m, 0.0, places=2)
        self.assertGreater(g.lat, 36.8)

    def test_45_degrees_heading_east(self):
        g = project_pixel(Pose(36.8, 10.18, 100, 90, -45), W / 2, H / 2, W, H, FOV)
        self.assertAlmostEqual(g.east_m, 100.0, places=2)
        self.assertAlmostEqual(g.north_m, 0.0, places=2)

    def test_right_of_image_is_east_when_looking_north_down(self):
        g = project_pixel(Pose(36.8, 10.18, 100, 0, -90), W * 0.9, H / 2, W, H, FOV)
        self.assertGreater(g.east_m, 0)
        self.assertAlmostEqual(g.north_m, 0.0, places=2)

    def test_top_of_image_is_north_when_looking_north_down(self):
        g = project_pixel(Pose(36.8, 10.18, 100, 0, -90), W / 2, H * 0.1, W, H, FOV)
        self.assertGreater(g.north_m, 0)

    def test_horizon_returns_none(self):
        self.assertIsNone(project_pixel(Pose(36.8, 10.18, 100, 0, 0), W / 2, H / 2, W, H, FOV))

    def test_distance_matches_haversine(self):
        p = Pose(36.8, 10.18, 80, 30, -40)
        g = project_pixel(p, W / 2, H / 2, W, H, FOV)
        self.assertAlmostEqual(haversine_m(p.lat, p.lon, g.lat, g.lon), g.distance_m, delta=0.5)

    def test_uncertainty_grows_with_distance(self):
        near = estimate_uncertainty_m(Pose(36.8, 10.18, 60, 0, -80), W / 2, H / 2, W, H, FOV)
        far = estimate_uncertainty_m(Pose(36.8, 10.18, 60, 0, -25), W / 2, H / 2, W, H, FOV)
        self.assertGreater(far, near)
        self.assertGreaterEqual(near, 3.0)       # au moins l'erreur GPS

    def test_known_zone(self):
        zones = [{"name": "Torche", "lat": 36.8, "lon": 10.18, "radius_m": 40}]
        self.assertEqual(match_known_zone(36.80010, 10.18, zones), "Torche")
        self.assertIsNone(match_known_zone(36.81, 10.18, zones))


if __name__ == "__main__":
    unittest.main()
