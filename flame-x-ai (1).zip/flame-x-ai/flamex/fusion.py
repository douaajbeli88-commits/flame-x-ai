"""Fusion : combine camera (IA), thermique et gaz en UN score, puis decide du niveau d'alerte.

Niveaux (correspondent aux couleurs de la carte du projet) :
  NORMAL     -> rien a signaler
  A_VERIFIER -> orange : information incomplete, un humain doit verifier
  ALERTE     -> rouge  : plusieurs indices concordants, sur plusieurs images de suite
Le systeme ne decide JAMAIS seul d'appeler les secours : la validation reste humaine.
"""
from dataclasses import dataclass, field
from typing import List, Optional

NORMAL, A_VERIFIER, ALERTE = "NORMAL", "A_VERIFIER", "ALERTE"


def _clip01(x: float) -> float:
    return max(0.0, min(1.0, x))


@dataclass
class Evidence:
    fire_conf: float = 0.0
    smoke_conf: float = 0.0
    thermal_max_c: Optional[float] = None     # None = pas de camera thermique
    gas_lel_pct: Optional[float] = None       # None = pas de capteur de gaz
    vision_available: bool = True


@dataclass
class Decision:
    level: str
    score: float
    reasons: List[str] = field(default_factory=list)
    positive_sources: int = 0
    streak: int = 0


class FusionEngine:
    def __init__(self, cfg: dict):
        f, t, g = cfg["fusion"], cfg["thermal"], cfg["gas"]
        self.w = f["weights"]
        self.warn, self.alert = f["warn_score"], f["alert_score"]
        self.confirm, self.strong = int(f["confirm_frames"]), f["strong_vision"]
        self.t_warn, self.t_alert = t["warn_c"], t["alert_c"]
        self.gas_max = g["max_lel_pct"]
        self.alert_streak = self.warn_streak = 0

    def scores(self, ev: Evidence) -> dict:
        s = {}
        if ev.vision_available:
            s["vision"] = _clip01(max(ev.fire_conf, 0.7 * ev.smoke_conf))   # la fumee seule est un indice moins sur
        if ev.thermal_max_c is not None:
            s["thermal"] = _clip01((ev.thermal_max_c - self.t_warn) / (self.t_alert - self.t_warn))
        if ev.gas_lel_pct is not None:
            s["gas"] = _clip01(ev.gas_lel_pct / self.gas_max)
        return s

    def update(self, ev: Evidence) -> Decision:
        s = self.scores(ev)
        if not s:
            return Decision(NORMAL, 0.0)
        wsum = sum(self.w[k] for k in s)
        score = sum(self.w[k] * v for k, v in s.items()) / wsum      # on renormalise si une source manque
        positives = sum(1 for v in s.values() if v > 0.5)

        reasons = []
        if "vision" in s and s["vision"] > 0:
            reasons.append(f"camera: feu {ev.fire_conf:.2f} / fumee {ev.smoke_conf:.2f}")
        if "thermal" in s and ev.thermal_max_c >= self.t_warn:
            reasons.append(f"thermique: {ev.thermal_max_c:.0f} C")
        if "gas" in s and s["gas"] > 0:
            reasons.append(f"gaz: {ev.gas_lel_pct:.1f} %LIE")

        alert_candidate = score >= self.alert and (positives >= 2 or s.get("vision", 0) >= self.strong)
        warn_candidate = score >= self.warn
        self.alert_streak = self.alert_streak + 1 if alert_candidate else 0
        self.warn_streak = self.warn_streak + 1 if warn_candidate else 0

        if self.alert_streak >= self.confirm:
            level = ALERTE
        elif self.warn_streak >= max(2, self.confirm // 2):
            level = A_VERIFIER
        else:
            level = NORMAL
        return Decision(level, score, reasons, positives, max(self.alert_streak, self.warn_streak))
