"""FLAME-X : prototype d'IA pour la detection et la localisation d'incendies par drone."""
__version__ = "0.1.0"
