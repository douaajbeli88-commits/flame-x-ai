"""Telemetrie du drone : position GPS, hauteur, cap et inclinaison de la camera."""
from .geolocation import Pose


class FixedTelemetry:
    """Position simulee, lue dans le fichier de reglages (pour tester sans drone)."""

    def __init__(self, cfg: dict):
        f = cfg["telemetry"]["fixed"]
        self.pose = Pose(f["lat"], f["lon"], f["alt_agl_m"], f["heading_deg"], f["pitch_deg"])

    def get(self) -> Pose:
        return self.pose


class MavlinkTelemetry:
    """Lit la vraie position via MAVLink (ArduPilot / PX4). Necessite `pip install pymavlink`."""

    def __init__(self, cfg: dict):
        from pymavlink import mavutil
        m = cfg["telemetry"]["mavlink"]
        self.link = mavutil.mavlink_connection(m["connection"], baud=m.get("baud", 57600))
        if self.link.wait_heartbeat(timeout=10) is None:
            print("[TELEMETRIE] Aucun signal MAVLink recu.")
        self.pitch = m.get("default_pitch_deg", -45)
        self.pose = None

    def get(self):
        while True:
            msg = self.link.recv_match(blocking=False)
            if msg is None:
                break
            t = msg.get_type()
            if t == "GLOBAL_POSITION_INT":
                hdg = msg.hdg / 100.0 if msg.hdg != 65535 else (self.pose.heading_deg if self.pose else 0.0)
                self.pose = Pose(msg.lat / 1e7, msg.lon / 1e7, msg.relative_alt / 1000.0, hdg, self.pitch)
            elif t == "MOUNT_ORIENTATION":          # inclinaison reelle du gimbal si disponible
                self.pitch = msg.pitch
                if self.pose:
                    self.pose.pitch_deg = self.pitch
        return self.pose


def make_telemetry(cfg: dict):
    return MavlinkTelemetry(cfg) if cfg["telemetry"]["mode"] == "mavlink" else FixedTelemetry(cfg)
