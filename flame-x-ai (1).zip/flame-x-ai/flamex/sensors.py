"""Capteurs de gaz. Le prototype fournit seulement une SIMULATION.

Pour de vrais capteurs en raffinerie il faut des detecteurs CERTIFIES (ATEX) valides par le site
(voir le rapport). Pour brancher le votre, creez une classe avec une methode read(t_s) qui
retourne le gaz en % de la LIE (limite inferieure d'explosivite).
"""
import random
from typing import Optional


class SimulatedGas:
    def __init__(self, fire_after_s: float = 8.0):
        self.fire_after_s = fire_after_s

    def read(self, t_s: float) -> Optional[float]:
        base = random.uniform(0.0, 1.5)
        return base + (18.0 if t_s >= self.fire_after_s else 0.0)


def make_gas_source(name: str, fire_after_s: float = 8.0):
    return SimulatedGas(fire_after_s) if name == "sim" else None
