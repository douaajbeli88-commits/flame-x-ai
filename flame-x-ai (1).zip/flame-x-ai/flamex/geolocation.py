"""Du pixel a la carte : estimer la position GPS d'un point vu par la camera.

Principe (voir le rapport) : le GPS donne la position du DRONE, pas celle du feu. On trace un
"rayon" de la camera vers le point observe, et on cherche ou ce rayon touche le sol.
HYPOTHESE : sol plat a l'altitude de reference. Pres de structures hautes (colonnes, reservoirs)
l'erreur augmente : c'est pour cela qu'on calcule aussi une marge d'incertitude.
Repere local : E = est, N = nord, U = haut. Cap 0 = nord, 90 = est. Tangage 0 = horizon, -90 = sol.
"""
import math
from dataclasses import dataclass, replace
from typing import Optional

EARTH_R = 6378137.0


@dataclass
class Pose:
    lat: float
    lon: float
    alt_agl_m: float
    heading_deg: float
    pitch_deg: float


@dataclass
class GroundPoint:
    lat: float
    lon: float
    east_m: float
    north_m: float
    distance_m: float


def _cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def project_pixel(pose: Pose, u, v, width, height, hfov_deg, max_range_m=3000.0) -> Optional[GroundPoint]:
    """Retourne le point au sol vu au pixel (u, v), ou None si le rayon ne touche pas le sol."""
    psi, th = math.radians(pose.heading_deg), math.radians(pose.pitch_deg)
    f = (math.sin(psi) * math.cos(th), math.cos(psi) * math.cos(th), math.sin(th))   # vers l'avant
    r = (math.cos(psi), -math.sin(psi), 0.0)                                           # vers la droite
    up = _cross(r, f)                                                                  # vers le haut de l'image
    tx = math.tan(math.radians(hfov_deg) / 2.0)
    ty = tx * height / width
    x = (u - width / 2.0) / (width / 2.0) * tx
    y = -(v - height / 2.0) / (height / 2.0) * ty
    d = tuple(f[i] + x * r[i] + y * up[i] for i in range(3))
    if d[2] >= -1e-6:                       # le rayon monte ou reste horizontal : pas d'intersection
        return None
    t = pose.alt_agl_m / -d[2]
    east, north = t * d[0], t * d[1]
    dist = math.hypot(east, north)
    if dist > max_range_m:
        return None
    lat = pose.lat + math.degrees(north / EARTH_R)
    lon = pose.lon + math.degrees(east / (EARTH_R * math.cos(math.radians(pose.lat))))
    return GroundPoint(lat, lon, east, north, dist)


def estimate_uncertainty_m(pose: Pose, u, v, width, height, hfov_deg,
                           gps_m=3.0, heading_err_deg=3.0, pitch_err_deg=2.0, alt_err_m=2.0,
                           max_range_m=3000.0) -> float:
    """Marge d'erreur (metres) : on fait varier chaque mesure de son erreur supposee,
    puis on combine les ecarts (racine de la somme des carres)."""
    base = project_pixel(pose, u, v, width, height, hfov_deg, max_range_m)
    if base is None:
        return max_range_m
    variations = [
        ("heading_deg", heading_err_deg), ("pitch_deg", pitch_err_deg), ("alt_agl_m", alt_err_m),
    ]
    total = gps_m ** 2
    for field, err in variations:
        worst = 0.0
        for sign in (+1, -1):
            p = replace(pose, **{field: getattr(pose, field) + sign * err})
            g = project_pixel(p, u, v, width, height, hfov_deg, max_range_m)
            dev = max_range_m if g is None else math.hypot(g.east_m - base.east_m, g.north_m - base.north_m)
            worst = max(worst, dev)
        total += worst ** 2
    return min(math.sqrt(total), max_range_m)


def haversine_m(lat1, lon1, lat2, lon2) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * EARTH_R * math.asin(math.sqrt(a))


def match_known_zone(lat, lon, zones):
    """Retourne le nom de la zone connue (ex: torche) qui contient ce point, sinon None."""
    for z in zones or []:
        if haversine_m(lat, lon, z["lat"], z["lon"]) <= z["radius_m"]:
            return z.get("name", "zone connue")
    return None
