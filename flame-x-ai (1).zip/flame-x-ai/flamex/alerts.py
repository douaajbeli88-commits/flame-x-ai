"""Alertes : image, ligne de journal (JSONL), carte (GeoJSON) et envoi optionnel au centre de controle."""
import json
import time
import urllib.request
from datetime import datetime
from pathlib import Path

import cv2


class AlertManager:
    def __init__(self, cfg: dict):
        a = cfg["alerts"]
        self.dir = Path(a["dir"])
        self.dir.mkdir(parents=True, exist_ok=True)
        self.webhook = a.get("webhook_url")
        self.cooldown = cfg["fusion"]["cooldown_s"]
        self.last_time = {}
        self.features = []
        self.count = 0

    def should_emit(self, level: str, now: float) -> bool:
        return now - self.last_time.get(level, -1e9) >= self.cooldown

    def emit(self, decision, frame, pose, ground, uncertainty_m, target_kind, extra_notes, processing_ms):
        now = time.time()
        self.last_time[decision.level] = now
        self.count += 1
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        alert_id = f"FX-{ts}-{self.count:03d}"
        img_name = f"{alert_id}.jpg"
        cv2.imwrite(str(self.dir / img_name), frame)

        has_target = ground is not None
        lat, lon = (ground.lat, ground.lon) if has_target else (pose.lat, pose.lon)
        record = {
            "id": alert_id, "time": datetime.now().isoformat(timespec="seconds"),
            "level": decision.level, "score": round(decision.score, 3),
            "reasons": decision.reasons + extra_notes,
            "position_type": "foyer_estime" if has_target else "position_drone",
            "target_kind": target_kind,
            "lat": lat, "lon": lon, "uncertainty_m": round(uncertainty_m, 1),
            "drone": {"lat": pose.lat, "lon": pose.lon, "alt_agl_m": pose.alt_agl_m,
                      "heading_deg": pose.heading_deg, "pitch_deg": pose.pitch_deg},
            "image": img_name, "processing_ms": round(processing_ms, 1),
        }
        with open(self.dir / "alerts.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\n")

        self.features.append({"type": "Feature",
                              "geometry": {"type": "Point", "coordinates": [lon, lat]},
                              "properties": record})
        with open(self.dir / "events.geojson", "w", encoding="utf-8") as f:
            json.dump({"type": "FeatureCollection", "features": self.features}, f, ensure_ascii=False, indent=1)

        print(f"[{record['level']}] {alert_id} score={record['score']} pos=({lat:.6f}, {lon:.6f}) "
              f"+/-{record['uncertainty_m']} m | {'; '.join(record['reasons'])}")
        self._send_webhook(record)
        return record

    def _send_webhook(self, record):
        """Envoi vers le centre de controle du site (jamais vers les secours sans accord officiel)."""
        if not self.webhook:
            return
        try:
            req = urllib.request.Request(self.webhook, data=json.dumps(record).encode("utf-8"),
                                         headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=3)
        except Exception as e:
            print(f"[ALERTE] envoi au centre de controle impossible : {e}")
