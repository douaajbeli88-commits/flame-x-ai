"""Module thermique : points chauds, tendance dans le temps, sources de donnees.

Une "image thermique" est ici un tableau de temperatures en degres Celsius (une valeur par pixel).
Une camera thermique radiometrique (ou un MLX90640) fournit ce type de tableau.
"""
from dataclasses import dataclass
from pathlib import Path
from typing import List, Optional

import cv2
import numpy as np


@dataclass
class Hotspot:
    cx: float
    cy: float
    x: int
    y: int
    w: int
    h: int
    max_c: float
    mean_c: float
    area_px: int


def detect_hotspots(temp_c: np.ndarray, threshold_c: float, min_area_px: int = 4, max_hotspots: int = 10) -> List[Hotspot]:
    """Trouve les groupes de pixels plus chauds que `threshold_c`."""
    mask = (temp_c >= threshold_c).astype(np.uint8)
    n, labels, stats, cents = cv2.connectedComponentsWithStats(mask, connectivity=8)
    out = []
    for i in range(1, n):
        area = int(stats[i, cv2.CC_STAT_AREA])
        if area < min_area_px:
            continue
        region = temp_c[labels == i]
        out.append(Hotspot(float(cents[i][0]), float(cents[i][1]),
                           int(stats[i, cv2.CC_STAT_LEFT]), int(stats[i, cv2.CC_STAT_TOP]),
                           int(stats[i, cv2.CC_STAT_WIDTH]), int(stats[i, cv2.CC_STAT_HEIGHT]),
                           float(region.max()), float(region.mean()), area))
    out.sort(key=lambda h: h.max_c, reverse=True)
    return out[:max_hotspots]


class ThermalTrend:
    """Prevention : repere une HAUSSE inhabituelle de temperature par zone de l'image.

    Chaque image est decoupee en grille ; on compare la temperature max actuelle de chaque case
    a sa mediane passee. (Dans un vrai deploiement, on comparerait des inspections du MEME
    equipement, identifie par sa position GPS ou son point de passage.)
    """

    def __init__(self, grid=(4, 4), history=30, delta_c=25.0, min_history=5):
        self.grid, self.history, self.delta_c, self.min_history = grid, history, delta_c, min_history
        self.mem = {}

    def update(self, temp_c: np.ndarray):
        gy, gx = self.grid
        h, w = temp_c.shape
        anomalies = []
        for j in range(gy):
            for i in range(gx):
                cell = temp_c[j * h // gy:(j + 1) * h // gy, i * w // gx:(i + 1) * w // gx]
                cur = float(cell.max())
                hist = self.mem.setdefault((j, i), [])
                if len(hist) >= self.min_history:
                    base = float(np.median(hist))
                    if cur - base >= self.delta_c:
                        anomalies.append({"cell": (j, i), "current_c": cur, "baseline_c": base})
                hist.append(cur)
                del hist[:-self.history]
        return anomalies


def make_synthetic_thermal(shape=(120, 160), ambient=32.0, hotspots=(), noise=1.0, seed=0) -> np.ndarray:
    """Image thermique fictive pour tester sans materiel. hotspots = [(cx_rel, cy_rel, rayon_px, temp_c)]."""
    rng = np.random.default_rng(seed)
    h, w = shape
    img = ambient + rng.normal(0, noise, shape)
    yy, xx = np.mgrid[0:h, 0:w]
    for cx_rel, cy_rel, radius, temp in hotspots:
        d2 = (xx - cx_rel * w) ** 2 + (yy - cy_rel * h) ** 2
        img = np.maximum(img, ambient + (temp - ambient) * np.exp(-d2 / (2 * (radius / 2.0) ** 2)))
    return img.astype(np.float32)


class ThermalSource:
    """Source d'images thermiques : 'none', 'synthetic' ou un dossier de fichiers .npy (en degres C)."""

    def __init__(self, arg: str = "none", fire_after_s: float = 8.0):
        self.mode, self.fire_after_s, self.files = "none", fire_after_s, []
        if arg == "synthetic":
            self.mode = "synthetic"
        elif arg != "none":
            p = Path(arg)
            self.files = sorted(p.glob("*.npy")) if p.is_dir() else [p]
            if not self.files:
                raise SystemExit(f"[ERREUR] Aucun fichier .npy dans {arg}")
            self.mode = "files"

    def read(self, frame_idx: int, t_s: float) -> Optional[np.ndarray]:
        if self.mode == "synthetic":
            spots = [(0.2, 0.7, 14, 95.0)]                      # une conduite chaude NORMALE
            if t_s >= self.fire_after_s:
                spots.append((0.62, 0.45, 10, 480.0))           # un foyer apparait
            return make_synthetic_thermal(hotspots=spots, seed=frame_idx % 7)
        if self.mode == "files":
            return np.load(self.files[frame_idx % len(self.files)]).astype(np.float32)
        return None
