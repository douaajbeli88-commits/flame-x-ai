"""Lecture du fichier de reglages YAML."""
from pathlib import Path

import yaml


def load_config(path="configs/flamex.yaml"):
    p = Path(path)
    if not p.exists():
        raise SystemExit(f"[ERREUR] Fichier de reglages introuvable : {p}")
    with open(p, encoding="utf-8") as f:
        return yaml.safe_load(f)
